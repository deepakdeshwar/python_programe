from django.contrib import admin
from.models import student1
admin.site.register(student1)
# Register your models here.
