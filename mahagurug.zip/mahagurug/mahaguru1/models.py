from django.db import models

    


# Create your models here.    
class student1(models.Model):
    First_Name=models.CharField(max_length=20)
    Last_Name=models.CharField(max_length=20)
    Gender=models.CharField(max_length=20,blank=True)
    Phone=models.CharField(max_length=20)
    Cource=models.CharField(max_length=20)
    #Date_Of_Birth=models.DateField(blank=True)
   # user=models.OneToOneField(user,on_delete=models.CASCADE)
    Email=models.EmailField(max_length=30 ,unique=True, null=False)
    password=models.CharField(max_length=20,blank=True)

    c1=models.PositiveIntegerField(null=True)
    c2=models.PositiveIntegerField(null=True)
    c3=models.PositiveIntegerField(null=True)
    c4=models.PositiveIntegerField(null=True)
    c5=models.PositiveIntegerField(null=True)
    c6=models.PositiveIntegerField(null=True)
    c7=models.PositiveIntegerField(null=True)
    c8=models.PositiveIntegerField(null=True)
    c9=models.PositiveIntegerField(null=True)
    c10=models.PositiveIntegerField(null=True)


    cpp1=models.PositiveIntegerField(null=True)
    cpp2=models.PositiveIntegerField(null=True)
    cpp3=models.PositiveIntegerField(null=True)
    cpp4=models.PositiveIntegerField(null=True)
    cpp5=models.PositiveIntegerField(null=True)
    cpp6=models.PositiveIntegerField(null=True)
    cpp7=models.PositiveIntegerField(null=True)
    cpp8=models.PositiveIntegerField(null=True)
    cpp9=models.PositiveIntegerField(null=True)
    cpp10=models.PositiveIntegerField(null=True)

 

    j1=models.PositiveIntegerField(null=True)
    j2=models.PositiveIntegerField(null=True)
    j3=models.PositiveIntegerField(null=True)
    j4=models.PositiveIntegerField(null=True)
    j5=models.PositiveIntegerField(null=True)
    j6=models.PositiveIntegerField(null=True)
    j7=models.PositiveIntegerField(null=True)
    j8=models.PositiveIntegerField(null=True)
    j9=models.PositiveIntegerField(null=True)
    j10=models.PositiveIntegerField(null=True)


    html1=models.PositiveIntegerField(null=True)
    html2=models.PositiveIntegerField(null=True)
    html3=models.PositiveIntegerField(null=True)
    html4=models.PositiveIntegerField(null=True)
    html5=models.PositiveIntegerField(null=True)
    html6=models.PositiveIntegerField(null=True)
    html7=models.PositiveIntegerField(null=True)
    html8=models.PositiveIntegerField(null=True)
    html9=models.PositiveIntegerField(null=True)
    html10=models.PositiveIntegerField(null=True)


    css1=models.PositiveIntegerField(null=True)
    css2=models.PositiveIntegerField(null=True)
    css3=models.PositiveIntegerField(null=True)
    css4=models.PositiveIntegerField(null=True)
    css5=models.PositiveIntegerField(null=True)
    css6=models.PositiveIntegerField(null=True)
    css7=models.PositiveIntegerField(null=True)
    css8=models.PositiveIntegerField(null=True)
    css9=models.PositiveIntegerField(null=True)
    css10=models.PositiveIntegerField(null=True)


    js1=models.PositiveIntegerField(null=True)
    js2=models.PositiveIntegerField(null=True)
    js3=models.PositiveIntegerField(null=True)
    js4=models.PositiveIntegerField(null=True)
    js5=models.PositiveIntegerField(null=True)
    js6=models.PositiveIntegerField(null=True)
    js7=models.PositiveIntegerField(null=True)
    js8=models.PositiveIntegerField(null=True)
    js9=models.PositiveIntegerField(null=True)
    js10=models.PositiveIntegerField(null=True)


    php1=models.PositiveIntegerField(null=True)
    php2=models.PositiveIntegerField(null=True)
    php3=models.PositiveIntegerField(null=True)
    php4=models.PositiveIntegerField(null=True)
    php5=models.PositiveIntegerField(null=True)
    php6=models.PositiveIntegerField(null=True)
    php7=models.PositiveIntegerField(null=True)
    php8=models.PositiveIntegerField(null=True)
    php9=models.PositiveIntegerField(null=True)
    php10=models.PositiveIntegerField(null=True)

    cf1=models.PositiveIntegerField(null=True)
    cf2=models.PositiveIntegerField(null=True)
    cf3=models.PositiveIntegerField(null=True)
    cf4=models.PositiveIntegerField(null=True)
    cf5=models.PositiveIntegerField(null=True)
    cf6=models.PositiveIntegerField(null=True)
    cf7=models.PositiveIntegerField(null=True)
    cf8=models.PositiveIntegerField(null=True)
    cf9=models.PositiveIntegerField(null=True)
    cf10=models.PositiveIntegerField(null=True)

    sql1=models.PositiveIntegerField(null=True)
    sql2=models.PositiveIntegerField(null=True)
    sql3=models.PositiveIntegerField(null=True)
    sql4=models.PositiveIntegerField(null=True)
    sql5=models.PositiveIntegerField(null=True)
    sql6=models.PositiveIntegerField(null=True)
    sql7=models.PositiveIntegerField(null=True)
    sql8=models.PositiveIntegerField(null=True)
    sql9=models.PositiveIntegerField(null=True)
    sql10=models.PositiveIntegerField(null=True)

    os1=models.PositiveIntegerField(null=True)
    os2=models.PositiveIntegerField(null=True)
    os3=models.PositiveIntegerField(null=True)
    os4=models.PositiveIntegerField(null=True)
    os5=models.PositiveIntegerField(null=True)
    os6=models.PositiveIntegerField(null=True)
    os7=models.PositiveIntegerField(null=True)
    os8=models.PositiveIntegerField(null=True)
    os9=models.PositiveIntegerField(null=True)
    os10=models.PositiveIntegerField(null=True)

    cn1=models.PositiveIntegerField(null=True)
    cn2=models.PositiveIntegerField(null=True)
    cn3=models.PositiveIntegerField(null=True)
    cn4=models.PositiveIntegerField(null=True)
    cn5=models.PositiveIntegerField(null=True)
    cn6=models.PositiveIntegerField(null=True)
    cn7=models.PositiveIntegerField(null=True)
    cn8=models.PositiveIntegerField(null=True)
    cn9=models.PositiveIntegerField(null=True)
    cn10=models.PositiveIntegerField(null=True)

    dc1=models.PositiveIntegerField(null=True)
    dc2=models.PositiveIntegerField(null=True)
    dc3=models.PositiveIntegerField(null=True)
    dc4=models.PositiveIntegerField(null=True)
    dc5=models.PositiveIntegerField(null=True)
    dc6=models.PositiveIntegerField(null=True)
    dc7=models.PositiveIntegerField(null=True)
    dc8=models.PositiveIntegerField(null=True)
    dc9=models.PositiveIntegerField(null=True)
    dc10=models.PositiveIntegerField(null=True)

    ca1=models.PositiveIntegerField(null=True)
    ca2=models.PositiveIntegerField(null=True)
    ca3=models.PositiveIntegerField(null=True)
    ca4=models.PositiveIntegerField(null=True)
    ca5=models.PositiveIntegerField(null=True)
    ca6=models.PositiveIntegerField(null=True)
    ca7=models.PositiveIntegerField(null=True)
    ca8=models.PositiveIntegerField(null=True)
    ca9=models.PositiveIntegerField(null=True)
    ca10=models.PositiveIntegerField(null=True)


    ds1=models.PositiveIntegerField(null=True)
    ds2=models.PositiveIntegerField(null=True)
    ds3=models.PositiveIntegerField(null=True)
    ds4=models.PositiveIntegerField(null=True)
    ds5=models.PositiveIntegerField(null=True)
    ds6=models.PositiveIntegerField(null=True)
    ds7=models.PositiveIntegerField(null=True)
    ds8=models.PositiveIntegerField(null=True)
    ds9=models.PositiveIntegerField(null=True)
    ds10=models.PositiveIntegerField(null=True)

    db1=models.PositiveIntegerField(null=True)
    db2=models.PositiveIntegerField(null=True)
    db3=models.PositiveIntegerField(null=True)
    db4=models.PositiveIntegerField(null=True)
    db5=models.PositiveIntegerField(null=True)
    db6=models.PositiveIntegerField(null=True)
    db7=models.PositiveIntegerField(null=True)
    db8=models.PositiveIntegerField(null=True)
    db9=models.PositiveIntegerField(null=True)
    db10=models.PositiveIntegerField(null=True)
    


    p1=models.PositiveIntegerField(null=True)
    p2=models.PositiveIntegerField(null=True)
    p3=models.PositiveIntegerField(null=True)
    p4=models.PositiveIntegerField(null=True)
    p5=models.PositiveIntegerField(null=True)
    p6=models.PositiveIntegerField(null=True)
    p7=models.PositiveIntegerField(null=True)
    p8=models.PositiveIntegerField(null=True)
    p9=models.PositiveIntegerField(null=True)
    p10=models.PositiveIntegerField(null=True)

    

    create_date=models.DateTimeField(auto_now_add=True,null=True,blank=True)
    update_date=models.DateTimeField(auto_now=True,null=True,blank=True)

   # points=models.IntegerField(blank=True,null=True)


   # products=models.ManyToManyField(products,null=True)
    def __str__(self):
        return self.First_Name

class messages(models.Model):
    Name=models.CharField(max_length=20)
    Phone=models.CharField(max_length=20)
    Email=models.EmailField(max_length=30)
    Message=models.TextField(max_length=200)
    create_date=models.DateTimeField(auto_now_add=True,null=True,blank=True)
    update_date=models.DateTimeField(auto_now=True,null=True,blank=True)



   # points=models.IntegerField(blank=True,null=True)


   # products=models.ManyToManyField(products,null=True)
    def __str__(self):
        return self.First_Name


