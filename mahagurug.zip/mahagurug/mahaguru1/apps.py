from django.apps import AppConfig


class Mahaguru1Config(AppConfig):
    name = 'mahaguru1'
